# Written Analysis of the Election Audit

## Overview of Project

### Purpose

The purpose of this analysis was to create a simple analysis and have that analysis be in a text file.

## Election-Audit Results

- How many votes were cast in this congressional election? There were 369,711 votes

-Provide a breakdown of the number of votes and the percentage of total votes for each county in the precinct.
Denver had approximately 82.8 percent. Jefferson had 10.5 percent of the votes. Araphoe had 6.7 

-Which county had the largest number of votes? Denver had the largest number of votes

-Provide a breakdown of the number of votes and the percentage of the total votes each candidate received.
Charles Casper Stockham had 23 percent. Diana DeGette (the winner) had 73.8 percent. Raymon Anthony Doane 3.1 percent.

-Which candidate won the election, what was their vote count, and what was their percentage of the total votes?
Diana DeGette won the election with 272,892 votes, and the percentage of votes she obatained was 73.8.

## Election-Audit Summary:

-This script can be used in other elections for:
	1) If we change the code we could find how many votes were given to each candidate from each county
	2) We could also change the code to not include counties for smaller elections, like town mayor.

